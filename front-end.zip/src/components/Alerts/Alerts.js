import React from "react";
import { Button } from "reactstrap";
import "./Alerts.css";

export default function Alerts() {
    return (
      <div className="alerts_container">
          <div className="alerts_text">
            <p>
                <h1><strong>Notificações</strong></h1>
            
            </p>
        </div>
      </div>
    );
  }